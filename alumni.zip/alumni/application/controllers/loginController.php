<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class loginController extends CI_Controller {

	public function index()
	{
	
	
      $data['title'] = 'School Login';
			$this->load->view('login/login', $data);
      
	}
}
